using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using TanksRebirth.GameContent.ID;
using TanksRebirth.GameContent.Systems.LevelSystem;
using TanksRebirth.GameContent.Tanks;
using TanksRebirth.GameContent.Tanks.AI;
using TanksRebirth.Internals;
using TanksRebirth.Internals.Common.Framework.Audio;
using TanksRebirth.Internals.Common.Utilities;
using TanksRebirth.Net;

namespace TanksRebirth.GameContent;

public class Explosion : IAITankDanger {
    public delegate void PostUpdateDelegate(Explosion explosion);
    public static event PostUpdateDelegate? OnPostUpdate;

    /// <summary>The "owner" of this explosion.</summary>
    public Tank? Owner;

    // 500 -> 80
    public const int EXPLOSIONS_MAX = 80;

    public static Explosion[] Explosions = new Explosion[EXPLOSIONS_MAX];
    public Vector2 Position { get; set; }
    public bool IsPlayerSourced { get; set; }
    /// <summary>
    /// An array representation of what tanks this explosion has already hit.
    /// If a tank's global ID is in this array, it has been damaged by this <see cref="Explosion"/>, and will not be damaged again by it.
    /// </summary>
    public bool[] HasHit = new bool[GameHandler.AllTanks.Length];
    public Vector3 Position3D => Position.ExpandZ();

    /// <summary>Only merlin himself could decode why I use this... Use this number with any explosion-based calculations.</summary>
    public const float MAGIC_EXPLOSION_NUMBER = 9f;
    public int Id { get; private set; }
    public int Team => Owner?.Team ?? TeamID.NoTeam;

    public float MaxScale;
    public float DamageRadiusScale;
    public float LingerDuration = 40f;
    public float Rotation;
    public float RotationSpeed;

    public float LifeTime;

    public Color ExplosionColor = Color.White;

    /// <summary>
    /// Creates a new <see cref="Explosion"/>. This method is thread-agnostic.
    /// </summary>
    /// <param name="pos">The position of this <see cref="Explosion"/> in the game world.</param>
    /// <param name="scale">How big this <see cref="Explosion"/> gets. Its damage radius is this times <see cref="MAGIC_EXPLOSION_NUMBER"/>.</param>
    /// <param name="owner">The <see cref="Tank"/> responsible for this <see cref="Explosion"/>, if any.</param>
    /// <param name="rotationSpeed">How fast the flames spin around the center.</param>
    /// <param name="soundPitch">Added to the pitch of the explosion sound.</param>
    /// <returns>The created <see cref="Explosion"/>, or <see langword="null"/> if there are already <see cref="EXPLOSIONS_MAX"/> explosions.</returns>
    public static Explosion? Create(Vector2 pos, float scale, Tank? owner = null, float rotationSpeed = 1f, float soundPitch = 0f) {
        var explosion = TankGame.ThreadAgnostic(() => Array.IndexOf(Explosions, null) < 0 ? null : new Explosion(pos, scale, owner, rotationSpeed, soundPitch));
        return explosion;
    }

    Explosion(Vector2 pos, float scale, Tank? owner = null, float rotationSpeed = 1f, float soundPitch = 0f) {
        RotationSpeed = rotationSpeed;
        Position = pos;
        MaxScale = scale;
        Owner = owner;

        AITank.Dangers.Add(this);
        IsPlayerSourced = owner is not null && owner is PlayerTank;

        int index = Array.IndexOf(Explosions, null);

        var destroysound = "Assets/sounds/mine_explode.ogg";

        int horizLayers = (int)(scale * 1.5f) + 2; // 10
        int vertLayers = (int)(scale * 1.1f) + 2; // 8

        var ring = GameHandler.Particles.MakeParticle(Position3D + Vector3.UnitY,
            /*ModelResources.FlatFace.Asset, */
            GameResources.GetGameResource<Texture2D>("Assets/textures/misc/ring"));

        ring.Scale = new(1.3f);
        ring.Pitch = MathHelper.PiOver2;
        ring.HasAdditiveBlending = true;
        ring.Color = ExplosionColor == Color.White ? Color.Yellow : ExplosionColor;

        ring.UniqueBehavior = (a) => {
            ring.Alpha -= 0.08f * RuntimeData.DeltaFrames;

            GeometryUtils.Add(ref ring.Scale, 0.04f * RuntimeData.DeltaFrames);
            if (ring.Alpha <= 0)
                ring.Destroy();
        };

        for (int i = 0; i <= horizLayers; i++) {
            for (int j = 0; j <= vertLayers; j++) {
                var rotX = MathHelper.Pi / vertLayers * j;
                var rotZ = MathHelper.Pi / horizLayers * i;

                float rotation = 0f;
                float rotationSpeed1 = 0.06f * RotationSpeed;

                // var explScalar = MAGIC_EXPLOSION_NUMBER * MaxScale;
                var lingerRandom = Client.ClientRandom.NextFloat(0.8f, 1.2f);
                var position = Vector3.UnitY * -5000f;
                var particle = GameHandler.Particles.MakeExplosionFlameParticle(position, out var act, LingerDuration / 60f * lingerRandom);

                // TODO: make particles face center of explosion -- i think this is done?
                particle.UniqueBehavior = (a) => {
                    act?.Invoke(particle);
                    particle.Color = ExplosionColor;
                    rotation += rotationSpeed1 * RuntimeData.DeltaFrames;
                    var explScalar = MAGIC_EXPLOSION_NUMBER * DamageRadiusScale;

                    // find why the rotation isnt rotating the right way. maybe needs a unit circle offset? piover2?
                    position = Vector3.Transform(Vector3.UnitX * explScalar, Matrix.CreateFromYawPitchRoll(rotZ + rotation, 0, rotX) * Matrix.CreateTranslation(Position3D));
                    particle.Position = position;

                    var rot = MathUtils.GetLookAtEulerAngles(particle.Position, Position3D);

                    particle.Roll = rot.Roll;
                    particle.Pitch = rot.Pitch;
                    particle.Yaw = rot.Yaw;
                };
            }
            horizLayers -= (int)MathF.Round((float)horizLayers / vertLayers);
        }
        var audio = SoundPlayer.PlaySoundInstance(destroysound, SoundContext.Effect, 1f, pitchOverride: soundPitch + GameUtils.NaturalPitchShift);
        //if (CameraGlobals.IsUsingFirstPresonCamera)
        //    SoundUtils.CreateSpatialSound(audio, Position3D, CameraGlobals.PerspectiveCamera.Position, 1.25f);

        Id = index;

        Explosions[index] = this;
    }
    
    public void Update() {
        DamageRadiusScale = MathUtils.SoftStep(DamageRadiusScale, MaxScale, 0.2f * RuntimeData.DeltaFrames);
        var damageRadiusReal = DamageRadiusScale * MAGIC_EXPLOSION_NUMBER;
        damageRadiusReal *= damageRadiusReal;

        if (!IntermissionSystem.IsAwaitingNewMission) {
            foreach (var mine in Mine.AllMines) {
                if (mine == null) continue;
                if (Vector3.DistanceSquared(mine.Position3D, Position3D) > damageRadiusReal) continue;
                
                mine.Detonate();
            }
            foreach (var block in Block.AllBlocks) {
                if (block == null) continue;
                if (!block.Properties.IsDestructible) continue;
                if (Vector3.DistanceSquared(block.Position3D, Position3D) > damageRadiusReal) continue;

                block.Destroy();
            }
            foreach (var shell in Shell.AllShells) {
                if (shell == null) continue;
                if (Vector3.DistanceSquared(shell.Position3D, Position3D) > damageRadiusReal) continue;

                shell.Destroy(Shell.DestructionContext.WithExplosion);
            }
            foreach (var tank in GameHandler.AllTanks) {
                if (tank is null) continue;
                if (tank.IsDestroyed || HasHit[tank.WorldId]) continue;
                if (Vector3.DistanceSquared(tank.Position3D, Position3D) > damageRadiusReal) continue;

                HasHit[tank.WorldId] = true;

                // only one client reports each hit, the others get it over the network
                if (!NetPlay.IsReporter(Owner)) continue;

                // Owner.Damage prevents damage within the method
                if (Owner == null)
                    tank.Damage(new TankHurtContextOther(null, TankHurtContextOther.HurtContext.FromIngame, "Unowned Explosion"), true);
                else
                    tank.Damage(new TankHurtContextExplosion(this), true);
            }
        }
        if (LifeTime > LingerDuration)
            Remove();

        Rotation += RotationSpeed * RuntimeData.DeltaFrames;
        LifeTime += RuntimeData.DeltaFrames;

        OnPostUpdate?.Invoke(this);
    }

    public void Remove() {
        AITank.Dangers.Remove(this);
        Explosions[Id] = null;
    }
}
