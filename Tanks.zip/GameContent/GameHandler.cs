﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Linq;
using TanksRebirth.Achievements;
using TanksRebirth.GameContent.Globals;
using TanksRebirth.GameContent.RebirthUtils;
using TanksRebirth.GameContent.Systems;
using TanksRebirth.GameContent.Systems.Coordinates;
using TanksRebirth.GameContent.Systems.LevelSystem;
using TanksRebirth.GameContent.Systems.ParticleSystem;
using TanksRebirth.GameContent.Systems.PingSystem;
using TanksRebirth.GameContent.Tanks;
using TanksRebirth.GameContent.Tanks.AI;

using TanksRebirth.GameContent.UI;
using TanksRebirth.GameContent.UI.LevelEditor;
using TanksRebirth.GameContent.UI.MainMenu;
using TanksRebirth.Graphics;
using TanksRebirth.Graphics.DynamicLighting;
using TanksRebirth.Internals.Common.Framework.Animation;
using TanksRebirth.Internals.Common.GameUI;
using TanksRebirth.Internals.Common.Utilities;
using TanksRebirth.Internals.UI;
using TanksRebirth.Net;

namespace TanksRebirth.GameContent;

#pragma warning disable CS8618
public class GameHandler {

    public const int MAX_AI_TANKS = 60;
    public const int MAX_PLAYERS = 4;
    //
    // public const int MAX_PARTICLES = 15000; // removed for now

    public delegate void PostRender();
    public static event PostRender? OnPostRender;
    public delegate void PostUpdate();
    public static event PostUpdate? OnPostUpdate;

    public static ParticleManager Particles { get; } = new(() => CameraGlobals.GameView, () => CameraGlobals.GameProjection) { DrawsFootprints = true };
    public static XpBar ExpBar;

    public static byte ActiveTankCount;
    public static byte ActiveAITankCount;
    public static byte ActivePlayerTankCount;
    public static AITank[] AllAITanks = new AITank[MAX_AI_TANKS];
    public static PlayerTank[] AllPlayerTanks = new PlayerTank[MAX_PLAYERS];
    public static Tank[] AllTanks = new Tank[MAX_PLAYERS + MAX_AI_TANKS];

    internal static void MapEvents() {
        CampaignGlobals.OnMissionEnd += IntermissionHandler.DoEndMissionWorkload;
        Tank.OnDamage += AttemptIntermission;
    }

    internal static void Initialize() {
        Client.ClientRandSeed = (int)DateTime.Now.Ticks;
        Client.ClientRandom = new(Client.ClientRandSeed);

        AllAITanks = new AITank[MAX_AI_TANKS];
        AllPlayerTanks = new PlayerTank[MAX_PLAYERS];
        AllTanks = new Tank[MAX_PLAYERS + MAX_AI_TANKS];

        ExpBar = new() {
            Level = (ushort)TankGame.SaveFile.ExpLevel
        };
        ExpBar.Value = TankGame.SaveFile.ExpLevel - ExpBar.Level;
        ExpBar.ApproachValue = ExpBar.Value;

        ExpBar.Alignment = Anchor.LeftCenter;
        ExpBar.FillColor = Color.Lime;
        ExpBar.EmptyColor = Color.Red;

        CosmeticsUI.Initialize();
    }

    static void AttemptIntermission(Tank victim, bool destroy, ITankHurtContext context) {
        if (!destroy) return;

        if (CampaignGlobals.ShouldMissionsProgress && !MainMenuUI.IsActive)
            CampaignProgression.CheckMissionCompletion();
    }

    internal static void GameLoopLogic(GameTime gameTime) {
        ActiveTankCount = (byte)AllTanks.Count(t => t is not null);
        ActiveAITankCount = (byte)AllAITanks.Count(t => t is not null);
        ActivePlayerTankCount = (byte)AllPlayerTanks.Count(t => t is not null);
        /*void doTestWithFont() {
            var str = 
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
                "abcdefghijklmnopqrstuvwxyz" +
                "1234567890" +
                "`[]\\;',./~{}|:\"<>?";
            int longestId = -1;
            var longest = 0f;
            for (int i = 0; i < str.Length; i++) {
                var x = FontGlobals.RebirthFontLarge.MeasureString(str[i].ToString()).X;
                if (x > longest) {
                    longestId = i;
                    longest = x;
                }
            }
            Console.WriteLine($"{str[longestId]} is the longest. ({longest})");
        }
        if (InputUtils.KeyJustPressed(Keys.OemTilde))
            doTestWithFont();*/

        ExpBar.Update();

        CosmeticsUI.Update();

        Modifiers.GlobalManage();

        if (MainMenuUI.IsActive)
            PlayerTank.SetLives(999);
        // technically, level 0 in code is level 1, so we want to use that number (1) if the user is level 0.
        // ExperienceBar.Value = TankGame.GameData.ExpLevel - MathF.Floor(TankGame.GameData.ExpLevel);

        VanillaAchievements.Repository.UpdateCompletions(TankGame.VanillaAchievementPopupHandler);

        if (RuntimeData.RunTime % 30 < RuntimeData.DeltaFrames) {
            Client.SendLives();
            Client.SendKillCounts();
        }

        /* uh, yeah. this is the decay-per-level calculation. people don't want it!
        var floor1 = MathF.Floor(TankGame.GameData.ExpLevel + 1f);
        var floor0 = MathF.Floor(TankGame.GameData.ExpLevel);
        GameData.UniversalExpMultiplier = floor1 - (GameData.DecayPerLevel * floor0);*/

        if (Modifiers.IsOn(Modifiers.INF_LIFE))
            PlayerTank.SetLives(PlayerTank.StartingLives);

        for (int i = 0; i < Animator.Animators.Count; i++)
            Animator.Animators[i].PlayAnimationIfRunning(gameTime);

        foreach (var ping in IngamePing.AllIngamePings)
            ping?.Update();

        if (GameScene.UpdateAndRender) {
            if (!IntermissionSystem.IsAwaitingNewMission) {
                foreach (var pTank in AllPlayerTanks)
                    pTank?.Update();

                // todo: reimpl
                AIManager.UpdateAITanks();

                foreach (var mine in Mine.AllMines)
                    mine?.Update();

                foreach (var bullet in Shell.AllShells)
                    bullet?.Update();

                foreach (var fp in TankFootprint.AllFootprints)
                    fp?.Update();

                foreach (var p in Airplane.AllPlanes)
                    p?.Update();
            }
            if (CampaignGlobals.InMission) {
                TankMusicSystem.Update();

                foreach (var crate in Crate.AllCrates)
                    crate?.Update();

                foreach (var pu in Powerup.Powerups)
                    pu?.Update();
            }
            else {
                foreach (var audio in TankMusicSystem.Audio.ToList()) {
                    audio.Value.Volume = 0;
                    audio.Value.Stop();
                }
            }

            // level editor update used to be here...?

            foreach (var expl in Explosion.Explosions)
                expl?.Update();

            foreach (var cube in Block.AllBlocks)
                cube?.OnUpdate();

            if ((DebugManager.DebuggingEnabled && DebugManager.DebugLevel == DebugManager.Id.LVL_DBG && CameraGlobals.OverheadView) || LevelEditorUI.IsActive)
                EditorTile.UpdateAll();

            Particles.UpdateParticles();
        }

        LevelEditorUI.Update();

        var mmActive = MainMenuUI.IsActive;
        if (mmActive)
            MainMenuUI.Update();
        // I AM PUTTING THIS HERE BECAUSE FUCK YOU.
        MainMenuUI.UpdateCampaignButton.IsVisible = MainMenuUI.MenuState == MainMenuUI.UIState.Campaigns && mmActive;

        // questioning as to why this is placed here
        if ((CameraGlobals.OverheadView || MainMenuUI.IsActive) && !LevelEditorUI.IsActive) {
            CampaignGlobals.InMission = false;
            IntermissionHandler.TankFunctionWait = 600;
        }

        SceneManager.HandleSceneVisuals();

        IntermissionHandler.Update();

        if (CameraGlobals.OverheadView)
            LevelEditorUI.HandleLevelEditorModifications();

        OnPostUpdate?.Invoke();
    }

    internal static void RenderAll(SpriteBatch spriteBatch) {
        TankGame.Instance.GraphicsDevice.BlendState = BlendState.AlphaBlend;
        
        // CHECK: move this back if necessary
        GameScene.RenderWorldModels();
        // TankFootprint.Draw();

        // TankGame.Instance.GraphicsDevice.DepthStencilState = DepthStencilState.Default;
        foreach (var tank in AllTanks) {
            if (tank == null) continue;
            // if (!CameraGlobals.ViewFrustum.Intersects(tank.Hurtbox)) continue;
            tank.Render();
        }

        // not worth doing culling logic for smaller tiny things. the tank render logic can be lengthy

        if (GameScene.UpdateAndRender) {

            foreach (var block in Block.AllBlocks)
                block?.OnRender();

            foreach (var mine in Mine.AllMines)
                mine?.Render();

            foreach (var bullet in Shell.AllShells)
                bullet?.Render();

            foreach (var mark in TankDeathMark.deathMarks)
                mark?.Render();

            foreach (var ping in IngamePing.AllIngamePings)
                ping?.Render();

            foreach (var p in Airplane.AllPlanes)
                p?.Render();

            //foreach (var print in TankFootprint.footprints)
            //print?.Render();

            foreach (var crate in Crate.AllCrates)
                crate?.Render();

            foreach (var powerup in Powerup.Powerups)
                powerup?.Render();

            Particles.RenderModelParticles();

            if ((DebugManager.DebugLevel == DebugManager.Id.LVL_DBG && CameraGlobals.OverheadView) || LevelEditorUI.IsActive)
                EditorTile.RenderAll();

            TankGame.Instance.GraphicsDevice.BlendState = BlendState.NonPremultiplied;

            Particles.RenderParticles(spriteBatch);
        }

        // shadows + lights, multiplied onto the world drawn so far. everything below is UI and stays unlit.
        LightingSystem.EndFrame(TankGame.GameFrameBuffer);

        // only render the level editor if it's active
        // change depth stencil...?
        if (LevelEditorUI.IsActive) {
            LevelEditorUI.Render(spriteBatch);
        }

        // only draw if ingame + is multiplayer.
        if (CampaignGlobals.ShouldMissionsProgress 
            && !MainMenuUI.IsActive
            && Client.IsConnected()) {
            PingMenu.DrawPingHUD();
        }

        IntermissionHandler.RenderCountdownGraphics();
        WiimoteSystem.DrawWiimoteBatteryLife(TankGame.SpriteRenderer, FontGlobals.RebirthFont);

        OnPostRender?.Invoke();
    }

    public static void RenderUI() {
        foreach (var element in UIElement.AllUIElements.ToList()) {
            if (!element.IsVisible) continue;
            // element.Position = Vector2.Transform(element.Position, UIMatrix * Matrix.CreateTranslation(element.Position.X, element.Position.Y, 0));
            if (element.Parent != null)
                continue;

            if (element.HasScissor)
                TankGame.SpriteRenderer.End();

            element?.Draw(TankGame.SpriteRenderer);

            if (element!.HasScissor)
                TankGame.SpriteRenderer.Begin(SpriteSortMode.Deferred, BlendState.NonPremultiplied, rasterizerState: RenderGlobals.DefaultRasterizer);
        }
        foreach (var element in UIElement.AllUIElements)
            element?.DrawTooltips(TankGame.SpriteRenderer);

        CameraGlobals.SetMatrices();
    }
    public static void SetupGraphics() {
        GameShaders.Initialize();
        GameScene.InitializeRenderers();
        SceneManager.LoadGameScene();
        DebugManager.InitDebugUI();
        EditorTile.InitializeLevelEditorSquares();
    }
}