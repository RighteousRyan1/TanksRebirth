﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Linq;
using TanksRebirth.Graphics;
using TanksRebirth.Internals.Common.Utilities;
using FontStashSharp;
using TanksRebirth.GameContent.RebirthUtils;
using TanksRebirth.GameContent.Globals;
using System.Collections.Generic;
using TanksRebirth.Graphics.Drawing;

namespace TanksRebirth.GameContent.Systems.ParticleSystem;

// currently unused...
public enum ParticleIntensity {
    None, // no particles at all
    Low, // Particles emit at 25% the frequency
    Medium, // ... 50%
    High, // ... 100%
}
public enum ParticleImportance {
    /// <summary>Must always render (e.g., player hit, mine explosion, damage feedback).</summary>
    Critical,
    /// <summary>Generally important for feedback, but the player can deduce what happens even without.</summary>
    Important,
    /// <summary>Particles that are pureply haptic and are not necessary in any regard.</summary>
    Cosmetic 
}
public class Particle {
    /// <summary>Data you may want to assign to this particle, such as assigning an owner to a particle, etc.</summary>
    public object Tag;

    /// <summary>The texture this <see cref="Particle"/> will use.</summary>
    public Texture2D Texture;

    /// <summary>The 3D model of this particle, if applicable.</summary>
    public Model Model;

    public Vector3 Position;
    /// <summary>The R, G, and B channels to use as a color for this <see cref="Particle"/>.</summary>
    public Color Color = Color.White;

    /// <summary>The X rotation of this <see cref="Particle"/>, if it's in 3D space.</summary>
    public float Roll;
    /// <summary>The Y rotation of this <see cref="Particle"/>, if it's in 3D space.</summary>
    public float Pitch;
    /// <summary>The Z rotation of this <see cref="Particle"/>, if it's in 3D space.</summary>
    public float Yaw;

    /// <summary>The scale of this <see cref="Particle"/>'s texture.</summary>
    public Vector2 TextureScale = Vector2.One;

    /// <summary>The rotation of the texture before and if this <see cref="Particle"/> exists in a 3D space.</summary>
    public float Rotation2D;

    public Vector2 Origin2D;
    /// <summary>The value from 0 (transparent) to 1 (opaque) of the alpha channel.</summary>
    public float Alpha = 1f;

    /// <summary>The unique identifier of this <see cref="Particle"/>.</summary>
    public int Id;

    /// <summary>Whether to billboard this <see cref="Particle"/> towards the camera, if in a 3D space.</summary>
    public bool Billboard;

    /// <summary>Whether or not this <see cref="Particle"/> should exist in a 2D space.</summary>
    public bool IsIn2DSpace;
    /// <summary>Whether or not this 2D particle should be translated from a 3D vector to screen space, if it exists in a 2D space.</summary>
    public bool ToScreenSpace = true;

    /// <summary>What this <see cref="Particle"/> should do every given update.</summary>
    public Action<Particle>? UniqueBehavior;

    /// <summary>What this <see cref="Particle"/> should do every given draw call.</summary>
    public Action<Particle>? UniqueDraw;

    /// <summary>Whether or not the color of this <see cref="Particle"/> has addative blending applied.</summary>
    public bool HasAdditiveBlending = true;

    /// <summary>How to crop the texture of this particle.</summary>
    public Rectangle? TextureCrop = null; // for framing a particle's texture

    /// <summary>How long (in ticks) this <see cref="Particle"/> particle has existed.</summary>
    public float LifeTime;

    /// <summary>Whether or not this <see cref="Particle"/> uses text instead of a texture.</summary>
    public bool IsText;
    /// <summary>The text that should show, if <see cref="IsText"/> is true.</summary>
    public string Text;

    /// <summary>The 3D scaling of this <see cref="Particle"/>.</summary>
    public Vector3 Scale;
    /// <summary>Light power multiplier for this <see cref="Particle"/>.</summary>
    public float LightPower = 1f;
    /// <summary>The <see cref="ParticleSystem"/> this <see cref="Particle"/> exists in.</summary>
    public ParticleManager System { get; }

    public float Layer;

    // Particle.cs is the gift that keeps on giving
    // particle system needs a billion different refactors
    /// <summary>If a 3D particle, ignores drawing these meshes (by name).</summary>
    public List<string> MeshesToIgnore = []; // to default as initialized or not as initialized, that is the question
    public ModelTextureMap Texturing;

    // /// <summary>If true, this particle will not halt drawing if not viewable.</summary>
    // public bool DrawAlways;
    /* TODO:
     * Model alpha must be set!
     * 
     * billboard from 'position' to the camera.
     */

    public bool ApplyGameLight = true;

    internal Particle(Vector3 position, ParticleManager system) {
        Position = position;
        System = system;

        Id = System.Register(this);
    }

    /// <summary>True once <see cref="Destroy"/> has been called. Destroyed particles are no longer updated or drawn.</summary>
    public bool Destroyed { get; internal set; }

    public void Update() {
        UniqueBehavior?.Invoke(this);
        LifeTime += RuntimeData.DeltaFrames;
    }

    public static BasicEffect EffectHandle = new(TankGame.Instance.GraphicsDevice);

    internal void DrawModel() {

        // this code causes draw order malfunction. ts pmo

        //TankGame.SpriteRenderer.End();

        //if (System.Scissor.HasValue) {
        //    TankGame.Instance.GraphicsDevice.ScissorRectangle = System.Scissor.Value;
        //}
        //TankGame.SpriteRenderer.Begin(blendState: HasAddativeBlending ? BlendState.Additive : BlendState.NonPremultiplied, rasterizerState: System.Rasterizer);
        Matrix world;

        if (Billboard) {
            world = Matrix.CreateScale(Scale) *
                    Matrix.CreateFromYawPitchRoll(Yaw, Pitch, Roll) *
                    Matrix.CreateBillboard(Position,
                                            CameraGlobals.PerspectiveCamera.Position,
                                            // up is wrong for some reason
                                            CameraGlobals.PerspectiveCamera.World.Down,
                                            CameraGlobals.PerspectiveCamera.World.Forward);
        }
        else {
            world = Matrix.CreateScale(Scale) *
                    Matrix.CreateFromYawPitchRoll(Yaw, Pitch, Roll) *
                    Matrix.CreateTranslation(Position);

            /*if (Billboard) world *= Matrix.CreateBillboard(Position,
                                            CameraGlobals.PerspectiveCamera.Position,
                                            // up is wrong for some reason
                                            CameraGlobals.PerspectiveCamera.World.Down,
                                            CameraGlobals.PerspectiveCamera.World.Forward);*/
        }
        foreach (ModelMesh mesh in Model.Meshes) {
            if (MeshesToIgnore.Contains(mesh.Name)) continue;

            foreach (BasicEffect effect in mesh.Effects) {
                effect.World = world;
                effect.View = System.SystemView;
                effect.Projection = System.SystemProjection;

                effect.TextureEnabled = true;

                if (Texturing != null && Texturing.Count > 0) effect.Texture = Texturing[mesh.Name];
                else effect.Texture = Texture;

                effect.Alpha = Alpha;

                effect.EmissiveColor = Color.ToVector3();

                if (ApplyGameLight) {
                    effect.EmissiveColor *= SceneManager.GameLight.Brightness;
                    effect.SetDefaultGameLighting_IngameEntities(LightPower);
                }
            }
            mesh.Draw();
        }
        // same here
        //TankGame.SpriteRenderer.End();
        //TankGame.SpriteRenderer.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend);
    }
    /// <summary>Draws a world-space text particle. Sprite (texture) particles are batched by <see cref="ParticleManager"/> instead.</summary>
    /// <remarks>Expects the <see cref="SpriteBatch"/> to be *ended*; manages its own Begin/End.</remarks>
    internal void DrawText3D(SpriteBatch spriteBatch) {
        Matrix world;

        if (Billboard) {
            world = Matrix.CreateScale(Scale) *
                    Matrix.CreateBillboard(Position,
                                            CameraGlobals.PerspectiveCamera.Position,
                                            CameraGlobals.PerspectiveCamera.World.Down,
                                            CameraGlobals.PerspectiveCamera.World.Forward);
        }
        else {
            world = Matrix.CreateScale(Scale) *
                    Matrix.CreateFromYawPitchRoll(Yaw, Pitch, Roll) *
                    Matrix.CreateTranslation(Position);
        }

        EffectHandle.World = world;
        EffectHandle.EmissiveColor = Color.ToVector3() * SceneManager.GameLight.Brightness;
        EffectHandle.Alpha = Alpha;

        if (ApplyGameLight) {
            EffectHandle.EmissiveColor *= SceneManager.GameLight.Brightness;
            EffectHandle.SetDefaultGameLighting_IngameEntities(LightPower);
        }

        spriteBatch.Begin(SpriteSortMode.FrontToBack, HasAdditiveBlending ? BlendState.Additive : BlendState.NonPremultiplied, SamplerState.PointWrap, DepthStencilState.DepthRead, RenderGlobals.DefaultRasterizer, EffectHandle);
        spriteBatch.DrawString(FontGlobals.RebirthFont, Text, Vector2.Zero, Color * Alpha, new Vector2(Scale.X, Scale.Y), Rotation2D, Origin2D, Layer);
        spriteBatch.End();
    }

    /// <summary>Queues a screen-space particle on an already-begun <see cref="SpriteBatch"/>.</summary>
    internal void Draw2D(SpriteBatch spriteBatch) {
        var pos = ToScreenSpace ?
            MatrixUtils.ConvertWorldToScreen(Vector3.Zero, Matrix.CreateTranslation(Position), System.SystemView, System.SystemProjection) :
            new Vector2(Position.X, Position.Y);

        if (!IsText)
            spriteBatch.Draw(Texture, pos, TextureCrop, Color * Alpha, Rotation2D, Origin2D != default ? Origin2D : Texture.Size() / 2, TextureScale, default, Layer);
        else
            TankGame.SpriteRenderer.DrawString(FontGlobals.RebirthFont, Text, pos, Color * Alpha, TextureScale, Rotation2D, Origin2D, Layer);
    }

    /// <summary>Removes this particle from its system. Safe to call multiple times; O(1).</summary>
    public void Destroy() {
        UniqueBehavior = null;
        UniqueDraw = null;

        if (Destroyed) return;
        Destroyed = true;
        System.Unregister(this);
    }
}