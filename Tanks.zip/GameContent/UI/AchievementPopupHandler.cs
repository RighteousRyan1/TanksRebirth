using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Threading.Tasks;
using TanksRebirth.Achievements;
using TanksRebirth.Internals;
using TanksRebirth.Internals.Common.Utilities;
using FontStashSharp;
using TanksRebirth.Internals.Common.Framework.Audio;
using TanksRebirth.GameContent.Globals;

namespace TanksRebirth.GameContent.UI;

public class AchievementPopupHandler(AchievementRepository repo) {
    Vector2 _popupPos;
    Vector2 _popupDims;
    string _title = string.Empty;
    string _description = string.Empty;
    Texture2D? _curTexture;

    volatile bool _isCurrentlyActive;

    float _textScale = 0.5f;

    public AchievementRepository Repo = repo;

    // question to self: why am i so addicted to asynchronous execution for things that don't need it?
    // TODO: change a lot. also implement achievements menu
    public void SummonOrQueue(int achievementId) {
        if (_isCurrentlyActive) {
            Task.Run(async () => {
                await Task.Delay(50);
                SummonOrQueue(achievementId);
            });
            return;
        }
        var achs = Repo.GetAchievements();

        if (achievementId >= achs.Count) {
            TankGame.ClientLog.Write($"Invalid achievement has been unlocked. achievementId = {achievementId}, Count = {achs.Count}", RebirthLogLevel.ErrorSilent);
        }

        var ach = achs[achievementId] as Achievement; // convert it to a standardized achievement.

        var hasTexture = ach!.Texture is not null;
        #pragma warning disable CS8604, CS8601
        if (hasTexture) {
            var achievementGet = "Assets/sounds/menu/achievement.ogg";

            SoundPlayer.PlaySoundInstance(achievementGet, SoundContext.Effect, 1f, 0f, 0f);
            _curTexture = ach.Texture;
            if (!string.IsNullOrEmpty(ach.Name)) {
                _title = ach.Name;
                _description = ach.Description;
                var titleMeasure = FontGlobals.RebirthFontLarge.MeasureString(_title) * _textScale;
                var descMeasure = FontGlobals.RebirthFontLarge.MeasureString(_description) * _textScale / 2;
                var biggerFloat = titleMeasure.X > descMeasure.X ? titleMeasure : descMeasure;
                _popupDims = ach.Texture.Size() + biggerFloat + new Vector2(100, 0);
                float interp = 0f;
                bool opening = true;
                var easingDelta = 0.02f * RuntimeData.DeltaFrames;
                _isCurrentlyActive = true;
                Task.Run(async () => {
                    while (interp < 1f && opening) {
                        var val = Easings.OutBounce(interp);
                        interp += easingDelta;
                        _popupPos = WindowUtils.WindowTop - new Vector2(_popupDims.X / 2, _popupDims.Y) + new Vector2(0, val * _popupDims.Y);
                        await Task.Delay(TimeSpan.FromMilliseconds((int)RuntimeData.LogicTime.TotalMilliseconds));
                    }
                    if (interp > 1f)
                        interp = 1f;
                    // 2 secs of delay before it closes.
                    await Task.Delay(2000);
                    opening = false;

                    while (interp > 0f) {
                        var val = Easings.InOutSine(interp);
                        interp -= easingDelta;
                        _popupPos = WindowUtils.WindowTop - new Vector2(_popupDims.X / 2, _popupDims.Y) + new Vector2(0, val * _popupDims.Y);
                        await Task.Delay(TimeSpan.FromMilliseconds((int)RuntimeData.LogicTime.TotalMilliseconds));
                    }
                    if (interp < 0f)
                        interp = 0f;
                    _isCurrentlyActive = false;
                });
            }
        }
        #pragma warning restore
    }

    public void DrawPopup(SpriteBatch spriteBatch) {
        spriteBatch.Draw(TextureGlobals.Pixels[Color.White], _popupPos, null, (Color.Beige.ToVector3() * 0.33f).ToColor(), 0f, Vector2.Zero, _popupDims, default, 0f);
        var texOff = Vector2.Zero;
        if (_curTexture is not null) {
            texOff = new Vector2(100, _popupDims.Y / 2);
            spriteBatch.Draw(_curTexture, _popupPos + texOff, null, Color.Beige, 0f, _curTexture.Size() / 2, Vector2.One, default, 0f);
        }
        var titleOff = new Vector2(100, 25);
        var descOff = new Vector2(0, 60);

        spriteBatch.DrawString(FontGlobals.RebirthFontLarge, _title, _popupPos + new Vector2(texOff.X, 0) + titleOff, Color.White, Vector2.One * _textScale, textStyle: TextStyle.Underline);
        spriteBatch.DrawString(FontGlobals.RebirthFontLarge, _description, _popupPos + new Vector2(texOff.X, 0) + titleOff + descOff, Color.White, Vector2.One * _textScale / 2);
    }
}
