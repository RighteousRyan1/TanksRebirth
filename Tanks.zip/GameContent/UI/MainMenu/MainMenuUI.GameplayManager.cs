using System.IO;
using TanksRebirth.GameContent.Globals;
using TanksRebirth.GameContent.RebirthUtils;
using TanksRebirth.Internals.Common.Utilities;
using TanksRebirth.Internals;
using TanksRebirth.GameContent.Systems.Coordinates;
using TanksRebirth.Net;
using TanksRebirth.GameContent.Systems.LevelSystem;
using TanksRebirth.GameContent.Tanks;

namespace TanksRebirth.GameContent.UI.MainMenu;

#pragma warning disable
public static partial class MainMenuUI {
    static bool _firstTime = true;
    public static void UpdateGameplay() {
        if (!TankGame.Settings.MenuGameplayEnabled) return;

        if (IntermissionSystem.IsAwaitingNewMission || IntermissionSystem.BlackAlpha > 0) return;
        if (curMenuMission.Blocks is null) {
            LoadTemplateMission();
            return;
        }
        // do not count player tanks into the check
        var missionComplete = CampaignProgression.VanillaCheckCompletion(curMenuMission, out _, (t) => t is not PlayerTank);

        if (missionComplete)
            LoadTemplateMission();
    }
    public static void OpenGP() {
        SceneManager.CleanupScene();
        SceneManager.CleanupEntities();
        PlayerTank.TankKills.Clear();

        if (!TankGame.Settings.MenuGameplayEnabled) return;

        LoadTemplateMission();
    }
    public static void LeaveGP() {
        SceneManager.StartTnkScene();
        PlayerTank.SetLives(PlayerTank.StartingLives);
        SceneManager.CleanupEntities();
        EditorTile.ResetSquares();
        SceneManager.CleanupScene();
        Theme.Stop();
    }
    static bool _failedFetch;
    private static void LoadTemplateMission(bool autoSetup = true, bool loadForMenu = true) {
        if (_failedFetch && _cachedMissions.Count == 0) return;

        // something here or after here is causing players' games to crash
        try {
            if (_firstTime) {
                _firstTime = false;
                var attempt = 1;

            tryAgain:
                var linkTry = $"https://github.com/RighteousRyan1/tanks_rebirth_motds/blob/master/menu_missions/Menu{attempt}.mission?raw=true";
                var bytes = WebUtils.DownloadWebFile(linkTry, out var name1, out var status);

                if (status == System.Net.HttpStatusCode.OK) {
                    using var stream1 = new MemoryStream(bytes);

                    _cachedMissions.Add(Mission.Read(stream1));
                    attempt++;
                    goto tryAgain;
                }
                else {
                    TankGame.ClientLog.Write($"Unable to fetch map data via the internet (at map={attempt}). Status: {status}", RebirthLogLevel.Warn);
                    _failedFetch = true;
                    return;
                }
            }

            var rand = Client.ClientRandom.Next(1, _cachedMissions.Count);

            var mission = _cachedMissions[rand];

            if (autoSetup) {
                CampaignGlobals.LoadedCampaign.LoadMission(mission);
                CampaignGlobals.LoadedCampaign.SetupLoadedMission(true);
            }
            if (loadForMenu)
                curMenuMission = mission;
        }
        catch {
            TankGame.ClientLog.Write("Unable to fetch map data via the internet. Oops!", RebirthLogLevel.Warn);
        }
    }

}
