using Microsoft.Xna.Framework;
using TanksRebirth.Internals.Common;
using System;
using TanksRebirth.Internals.UI;
using System.Collections.Generic;
using System.IO;

using TanksRebirth.GameContent.Globals;
using TanksRebirth.GameContent.ModSupport;
using TanksRebirth.Internals.Common.Utilities;
using TanksRebirth.GameContent.Systems;
using TanksRebirth.Internals.Common.Framework.Audio;
using TanksRebirth.Net;

using TanksRebirth.Internals.Common.Framework.Animation;
using TanksRebirth.Graphics;
using Microsoft.Xna.Framework.Graphics;
using TanksRebirth.GameContent.Systems.LevelSystem;
using TanksRebirth.GameContent.Tanks;

namespace TanksRebirth.GameContent.UI.MainMenu;

public static partial class MainMenuUI {
    public const float DEFAULT_BLUR = 0.0075f;
    // no eulerangles due to porting headaches
    public readonly struct MenuGraphicsState(Vector3 position, Vector3 angles, float blurFactor) {
        public readonly Vector3 Position = position;
        public readonly Vector3 Rotation = angles;
        public readonly float GaussianBlurFactor = blurFactor;
    }
    public static bool IsActive { get; private set; } = true;

    public static Animator CameraPositionAnimator;
    public static Animator CameraRotationAnimator;

    public static OggAudio TickSound;
    public static OggMusic Theme;

    static bool _musicFading;
    static float _goalBlur;

    public delegate void MenuOpenDelegate();
    public delegate void MenuCloseDelegate();
    public delegate void CampaignSelectedDelegate(Campaign campaign);
    public static event MenuOpenDelegate? OnMenuOpen;
    public static event MenuCloseDelegate? OnMenuClose;
    public static event CampaignSelectedDelegate? OnCampaignSelected;

    public static int MissionCheckpoint = 0;

    #region MenuCameraPositions

    public static EasingFunction CameraEasingFunction = EasingFunction.InOutQuad;
    public static TimeSpan CameraTransitionTime = TimeSpan.FromSeconds(2);

    // (most of) these magical vectors were found from flying around ingame.

    // if this dict does not contain the UIState we want, we just default to CamPosMain
    // cosmetics menu in the future can be just a simple transition over to a post where a player tank can render in front of the camera at
    // the camera's position plus the Camera's world forward matrix times a certain amount for distance
    public static readonly Dictionary<UIState, MenuGraphicsState> MenuGraphicsStates = new() {
        [UIState.Campaigns] = new MenuGraphicsState(new Vector3(330f, 204f, 879f), new Vector3(0, -0.18f, 0.29f), DEFAULT_BLUR), // seat headrest
        [UIState.PlayList] = new MenuGraphicsState(new Vector3(247.031f, 59.885f, 204.935f), new Vector3(0f, -0.404f, 1.397f), DEFAULT_BLUR),
        [UIState.Multiplayer] = new MenuGraphicsState(new Vector3(57.25f, 47.419f, -263.85f), new Vector3(0f, -0.53f, 3.78f), DEFAULT_BLUR), // behind game scene
        [UIState.Settings] = new MenuGraphicsState(new Vector3(1461f, 928f, 623f), new Vector3(0, -0.33f, 0.53f), DEFAULT_BLUR), // near grandfather clock
        [UIState.StatsMenu] = new MenuGraphicsState(new Vector3(-1121f, 176f, 439f), new Vector3(0, -0.231f, -0.67f), 0.05f), // near sheet music
        [UIState.Modifiers] = new MenuGraphicsState(new Vector3(-1189f, 288f, 2583f), new Vector3(0f, -0.25f, -2.27f), 0.005f), // near books
        [UIState.LoadingMods] = new MenuGraphicsState(new Vector3(-3443f, 2088f, 3183f), new Vector3(0, -0.6307f, -0.91f), 0.01f), // top of the door
        [UIState.Cosmetics] = new MenuGraphicsState(new Vector3(-953f, 1078f, 2753f), new Vector3(0f, -0.226f, -2.56f), 0f), // second-to-top shelf of bookshelf
        [UIState.Customizing] = new MenuGraphicsState(new Vector3(-938.39f, 1020.87f, 2987.82f), new Vector3(0.00f, -0.18f, -2.81f), 0f), // facing towards the hut bookshelves
        [UIState.ModsMenu] = new MenuGraphicsState(new Vector3(1305.43f, 1030.8687f, 340.08344f), new Vector3(0f, -0.6007973f, -0.789088f), DEFAULT_BLUR) // facing towards the clock pendulum
    };

    public static Vector3 CamPosMain = new(0, 150, GameScene.MAX_Z + 100); // this is in front of the game scene, viewing it
    public static Vector3 CamPosMainRotation = new(0, -0.5f, 0);

    #endregion

    internal static Mission curMenuMission;
    static readonly List<Mission> _cachedMissions = [];

    static bool _initialized;

    public static RebirthLogoModel RebirthLogo;
    public static void InitializeBasics() {
        TickSound = new OggAudio("Content/Assets/sounds/menu/menu_tick.ogg");
        CameraPositionAnimator = Animator.Create();
        CameraRotationAnimator = Animator.Create();
        MenuState = UIState.PrimaryMenu;
        RebirthLogo = new() {
            Position = new(0, 500, 250),
            Rotation = new(0, MathHelper.TwoPi, 0)
        };

        // LogoTexture = SteamworksUtils.GetAvatar(Steamworks.SteamUser.GetSteamID());
    }
    public static void InitializeUI() {
        if (_initialized) {
            foreach (var field in typeof(MainMenuUI).GetFields()) {
                if (field.GetValue(null) is UIElement uielem) {
                    uielem.Remove();
                    uielem = null;
                }
            }
        }
        _initialized = true;

        var font = FontGlobals.RebirthFont;
        InitializeMain(font);
        InitializeMP(font);

        _menuElements = [PlayButton, PlayButton_SinglePlayer, PlayButton_LevelEditor, PlayButton_Multiplayer, ConnectToServerButton,
            CreateServerButton, UsernameInput, IPInput, PortInput, PasswordInput, ServerNameInput,
            DifficultiesButton, StatsMenu, CreditsButton, ModsMenuButton];

        foreach (var e in _menuElements) {
            e.OnMouseOver = (uiElement) => SoundPlayer.PlaySoundInstance(TickSound, SoundContext.Effect);
        }
    }
    public static void Leave() {
        // call partially implemented methods
        MenuState = UIState.PlayList;
        LeaveUI();
        LeaveGP();
    }
    private static void UpdateModels() {
        RebirthLogo.Position = new Vector3(0, 300.ToResolutionY(), 0);

        // slowly return to normal if the mouse is not on-screen
        if (!MouseUtils.MouseOnScreen) {
            RebirthLogo.Rotation.X = MathUtils.SoftStep(RebirthLogo.Rotation.X, 0, 0.05f * RuntimeData.DeltaFrames);
            RebirthLogo.Rotation.Y = MathUtils.SoftStep(RebirthLogo.Rotation.Y, MathHelper.PiOver2, 0.05f * RuntimeData.DeltaFrames);

            RebirthLogo.Rotation_Tanks = new(MathHelper.PiOver2, 0, 0);
            return;
        }
        var scalar = MathHelper.PiOver4;

        var rotX = -(MouseUtils.Test.X - 0.5f) * scalar;
        var rotY = MathHelper.PiOver2 + (MouseUtils.Test.Y - 0.25f) * scalar;

        RebirthLogo.Rotation.X = MathUtils.SoftStep(RebirthLogo.Rotation.X, rotX, 0.1f * RuntimeData.DeltaFrames);
        RebirthLogo.Rotation.Y = MathUtils.SoftStep(RebirthLogo.Rotation.Y, rotY, 0.1f * RuntimeData.DeltaFrames);
    }
    public static void RenderModels() {
        UpdateModels();
        // TODO: change this to world view/world projection...? i think it would look better if the crate existed in world space
        // it would give reason to have the camera move over for the player.

        if (!IsActive) return;
        //RebirthLogo.Rotation = new(MathF.Sin(RuntimeData.RunTime / 100) * MathHelper.PiOver4, 0, 0);
        RebirthLogo.Scale = 0.8f.ToResolutionF();
        RebirthLogo.View = CameraGlobals.ScreenView;
        RebirthLogo.Projection = CameraGlobals.ScreenProjOrthographic;
        if (MenuState == UIState.PrimaryMenu || MenuState == UIState.PlayList)
            RebirthLogo.Render();
    }
    // this is super workaround-y.
    internal static int plrsConfirmed;
    public static bool PrepareGameplay(string name, bool wasConfirmed = true, bool netRecieved = false, int? missionId = null) {
        if (missionId.HasValue) {
            // ChatSystem.SendMessage("We have received a custom mission identifier", Color.Green);
            MissionCheckpoint = missionId.Value;
        }

        // FIXME: find the feedback loop that causes the recieving client to start a mission anyway...

        var path = Path.Combine("Campaigns", name + ".campaign");

        var checkPath = Path.Combine(TankGame.SaveDirectory, "Campaigns", $"{name}.campaign");

        void completePreparation(Campaign campaign) {
            CampaignGlobals.LoadedCampaign = campaign;

            CampaignGlobals.LoadedCampaign.LoadMission(MissionCheckpoint); // loading the mission specified

            PlayerTank.StartingLives = campaign.MetaData.StartingLives;
            IntermissionSystem.BannerColor = campaign.MetaData.MissionStripColor;
            IntermissionSystem.BackgroundColor = campaign.MetaData.BackgroundColor;
        }

        if (!wasConfirmed && netRecieved) {
            var ret = File.Exists(checkPath);
            if (ret)
                completePreparation(Campaign.Load(path));
            return ret;
        }

        if (!netRecieved && !wasConfirmed) { // when switch, do !wasConfirmed && !netRecieved
            if (Client.IsConnected()) {
                //Client.SendCampaignBytes(camp);
                Client.SendCampaignByName(name, MissionCheckpoint);
                return true;
            }
        }
        if (wasConfirmed) {
            var camp = Campaign.Load(path);

            Client.RequestStartGame(MissionCheckpoint, true);

            // if campaign verification across clients fails, RequestStartGame should come before this branch.
            // check if the CampaignCheckpoint number is less than the number of missions in the array
            if (MissionCheckpoint >= camp.CachedMissions.Length) {
                // if it is, notify the user that the checkpoint is too high via the chat, and play the error sound
                ChatSystem.SendMessage($"Campaign '{name}' has no mission {MissionCheckpoint + 1}.", Color.Red);
                SoundPlayer.SoundError();
                return false;
            }

            // if it is, load the mission
            completePreparation(camp);

            SetPlayButtonsVisibility(false);
            SetPrimaryMenuButtonsVisibility(false);
            SetMPButtonsVisibility(false);
            SetDifficultiesButtonsVisibility(false);

            TransitionToGame();
        }

        return true;
    }
    public static void TransitionToGame() {
        foreach (var elem in campaignNames)
            elem?.Remove();

        IntermissionSystem.TimeBlack = IntermissionSystem.DEF_TIMEBLACK;
        CampaignGlobals.ShouldMissionsProgress = true;
        _musicFading = true;

        IntermissionSystem.InitializeCountdowns();

        // this is a very important method that i forgot existed
        IntermissionSystem.BeginOperation(600);
    }

    public static float VolumeMultiplier = 1f;

    public static void Update() {
        if (!_initialized || !_diffButtonsInitialized) return;
        IntermissionSystem.IsAwaitingNewMission = false;

        UpdateUI();
        UpdateDifficulties();
        UpdateMusic();
        UpdateMP();

        if (MenuState == UIState.ModsMenu)
            UpdateModsMenu();

        // intermittent gameplay update, to keep fresh maps on the menu
        if (RuntimeData.RunTime % 60f < RuntimeData.DeltaFrames)
            UpdateGameplay();
    }
    public static void Open() {
        OpenUI();
        OpenAudio();
        OpenGP();

        // there used to be stuff that manually removed entities. i hope we didn't need that
        OnMenuOpen?.Invoke();
    }

    static int _oldwheel;

    public static void Render(SpriteBatch spriteBatch, GameTime gameTime) {
        if (!_initialized || !_diffButtonsInitialized)
            return;

        if (IsActive) {
            RenderGeneralUI(spriteBatch);

            GameShaders.BlurFactor = MathUtils.SoftStep(GameShaders.BlurFactor, _goalBlur, 0.01f);

            if (ModLoader.IsLoadingMods)
                ModLoader.DrawModLoading();

            switch (MenuState) {
                case UIState.Campaigns:
                    DrawCampaignsUI();
                    break;
                case UIState.Multiplayer:
                    DrawMPMenu(gameTime);
                    break;
                case UIState.StatsMenu:
                    DrawStatsMenu(gameTime);
                    break;
                case UIState.ModsMenu:
                    DrawModMenu(spriteBatch);
                    break;
                case UIState.Credits:
                    DrawCredits(spriteBatch);
                    break;
            }
        }

        // why does this need to be here?????????? doesn't work in Update()
        _oldwheel = InputUtils.DeltaScrollWheel;
    }
}