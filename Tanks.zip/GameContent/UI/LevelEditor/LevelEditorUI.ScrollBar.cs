using FontStashSharp;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using TanksRebirth.GameContent.Globals;
using TanksRebirth.Internals.Common.Utilities;

namespace TanksRebirth.GameContent.UI.LevelEditor; 
public static partial class LevelEditorUI {
    public static Dictionary<string, Texture2D> RenderTextures = [];
    static float _barOffset;
    static Vector2 _origClick;
    static float _maxScroll;
    static List<string> _renderNamesTanks = [];
    static List<string> _renderNamesBlocks = [];
    static List<string> _renderNamesPlayers = [];

    public static void DrawTankDescriptionFlavor() {
        if (!string.IsNullOrEmpty(_curDescription)) {
            var measure = FontGlobals.RebirthFont.MeasureString(_curDescription);
            int padding = 20;
            var orig = new Vector2(0, TextureGlobals.Pixels[Color.White].Size().Y);
            TankGame.SpriteRenderer.Draw(TextureGlobals.Pixels[Color.White],
                new Rectangle((int)(WindowUtils.WindowWidth / 2 - (measure.X / 2 + padding).ToResolutionX()), (int)(WindowUtils.WindowHeight * 0.8f), (int)(measure.X + padding * 2).ToResolutionX(), (int)(measure.Y + 20).ToResolutionY()),
                null,
                Color.White,
                0f,
                orig,
                default,
                0f);
            TankGame.SpriteRenderer.DrawString(FontGlobals.RebirthFont, _curDescription, new Vector2(WindowUtils.WindowWidth / 2, WindowUtils.WindowHeight * 0.78f), Color.Black, Vector2.One.ToResolution(), 0f, new Vector2(measure.X / 2, measure.Y));
        }
    }
}
