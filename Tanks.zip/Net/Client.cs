using LiteNetLib;
using LiteNetLib.Utils;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;
using System.IO;
using System.Linq;
using TanksRebirth.Enums;
using TanksRebirth.GameContent;
using TanksRebirth.GameContent.Globals;
using TanksRebirth.GameContent.ID;
using TanksRebirth.GameContent.Systems;
using TanksRebirth.GameContent.Systems.LevelSystem;
using TanksRebirth.GameContent.Tanks;
using TanksRebirth.GameContent.Tanks.AI;
using TanksRebirth.GameContent.UI;

using TanksRebirth.GameContent.UI.MainMenu;

namespace TanksRebirth.Net;
/// <summary>Contains many ways to send information across the nets. Used for vanilla packet handling.</summary>
public class Client {
    public delegate void ClientStart(Client client);
    public static event ClientStart? OnClientStart;
    public delegate void ClientDisconnected(Client client);
    public static event ClientDisconnected? OnClientDisconnect;

    public static NetManager ClientManager;
    public static EventBasedNetListener ClientListener;
    public static NetPeer NetClient;
    public static int PingTime = 60;
    public static bool LobbyDataReceived;

    public int Id;
    public string Name;
    public bool IsOperatedByPlayer;

    private static int _randSeed;
    public static int ClientRandSeed {
        get => _randSeed;
        set {
            _randSeed = value;
            ClientRandom = new(value);
        }
    }
    /// <summary>The randomizing behind the game's events. The seed can be modified if you change <see cref="ClientRandSeed"/>.</summary>
    public static Random ClientRandom { get; internal set; } = new();
    internal Client(int id, string username, bool isOperatedByPlayer = true) {
        Id = id;
        Name = username;
        IsOperatedByPlayer = isOperatedByPlayer;
    }

    public static void CreateClient(string username) {
        // a client from an earlier session that was never shut down
        ClientManager?.Stop();

        ClientListener = new();
        ClientManager = new(ClientListener) {
            NatPunchEnabled = true,
            UpdateTime = 15
        };
        ClientManager.Start();
        NetPlay.MapClientNetworking();

        Client c = new(0, username);

        TankGame.ClientLog.Write($"Created a new client with name '{username}'.", Internals.RebirthLogLevel.Debug);
        NetPlay.CurrentClient = c;
    }

    public static void AttemptConnectionTo(string address, int port, string password) {
        TankGame.ClientLog.Write($"Attempting connection to server...", Internals.RebirthLogLevel.Debug);
        ClientManager?.Start();
        NetClient = ClientManager!.Connect(address, port, password);
        if (NetClient is not null)
            OnClientStart?.Invoke(NetPlay.CurrentClient!);
    }

    public static void SendCommandUsage(string command) {
        if (!IsConnected()) return;

        NetDataWriter message = new();
        message.Put(PacketID.SendCommandUsage);
        message.Put(command);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendQuit() {
        if (MainMenuUI.IsActive || !IsConnected() || !IsHost())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.QuitLevel);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    /// <summary>Sends the host's mission result and everyone's lives, so clients end the mission the same way.</summary>
    public static void SendMissionEnd(int restartTime, MissionEndContext context, bool extraLife) {
        if (MainMenuUI.IsActive || !IsConnected() || !IsHost())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.MissionEnd);

        message.Put(restartTime);
        message.Put((int)context);
        message.Put(extraLife);
        message.Put(CampaignGlobals.LoadedCampaign.CurrentMissionId);

        message.Put(PlayerTank.Lives.Length);
        for (int i = 0; i < PlayerTank.Lives.Length; i++)
            message.Put(PlayerTank.Lives[i]);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendStartOver() {
        if (MainMenuUI.IsActive || !IsConnected() || !IsHost())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.StartOver);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendKillCounts() {
        if (MainMenuUI.IsActive || !IsConnected())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.SyncKills);

        var curClient = NetPlay.GetMyClientId();
        message.Put(curClient);
        message.Put(PlayerTank.KillCounts[curClient]);

        NetClient.Send(message, DeliveryMethod.Unreliable);
    }
    // int kind for the kind of plane soon?
    public static void SendAirplaneSpawn(Vector2 spawnPos, Vector2 velocity) {
        if (MainMenuUI.IsActive || !IsConnected())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.SendAirplane);

        message.Put(spawnPos);
        message.Put(velocity);

        NetClient.Send(message, DeliveryMethod.ReliableSequenced);
    }
    public static void SendLives() {
        if (MainMenuUI.IsActive || !IsConnected())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.SyncLives);

        var curClient = NetPlay.GetMyClientId();
        message.Put(curClient);
        message.Put(PlayerTank.GetMyLives());

        NetClient.Send(message, DeliveryMethod.Unreliable);
    }
    public static void SyncCleanup() {
        if (MainMenuUI.IsActive || !IsConnected())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.Cleanup);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendClientInfo() {
        NetDataWriter message = new();
        message.Put(PacketID.ClientInfo);
        message.Put(NetPlay.CurrentClient.Name);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void RequestLobbyInfo() {
        NetDataWriter message = new();
        message.Put(PacketID.LobbyInfo);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void RequestStartGame(int checkpoint, bool shouldProgressMissions) {
        if (MainMenuUI.IsActive || !IsConnected())
            return;
        NetDataWriter message = new();
        message.Put(PacketID.StartGame);
        message.Put(checkpoint);
        message.Put(shouldProgressMissions);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void RequestPlayerTankSpawn(PlayerTank tank) {
        NetDataWriter message = new();
        message.Put(PacketID.PlayerSpawn);

        message.Put(tank.PlayerType);
        message.Put(tank.Team);
        message.Put(tank.Physics.Position.X);
        message.Put(tank.Physics.Position.Y);
        message.Put(tank.ChassisRotation);
        message.Put(tank.TurretRotation);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SyncPlayerTank(PlayerTank tank) {
        if (!IsConnected())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.SyncPlayer);

        message.Put(tank.PlayerId);
        message.Put(tank.Physics.Position.X);
        message.Put(tank.Physics.Position.Y);
        message.Put(tank.ChassisRotation);
        message.Put(tank.TurretRotation);
        message.Put(tank.Velocity.X);
        message.Put(tank.Velocity.Y);

        NetClient.Send(message, DeliveryMethod.Unreliable);
    }
    public static void SyncAITank(AITank tank) {
        if (MainMenuUI.IsActive || !IsConnected())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.SyncAiTank);

        message.Put(tank.AITankId);
        message.Put(tank.Physics.Position.X);
        message.Put(tank.Physics.Position.Y);
        message.Put(tank.ChassisRotation);
        message.Put(tank.TurretRotation);
        message.Put(tank.Velocity.X);
        message.Put(tank.Velocity.Y);

        var targetExists = tank.TargetTank is not null;
        message.Put(targetExists);

        message.Put(tank.SeesTarget);

        // message.Put(tank.isin)

        if (targetExists)
            message.Put(tank.TargetTank!.WorldId);

        NetClient.Send(message, DeliveryMethod.Unreliable);
    }
    /// <summary>Be sure to sync by accessing the index of the tank from the AllTanks array. (<see cref="GameHandler.AllTanks"/>)</summary>
    public static void SyncShellFire(Shell shell) {
        if (MainMenuUI.IsActive || !IsConnected())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.ShellFire);

        message.Put(shell.Type);
        message.Put(shell.Position);
        message.Put(shell.Velocity);
        message.Put(shell.RicochetsRemaining);
        message.Put(shell.Owner!.WorldId);
        message.Put(shell.NetId);
        message.Put(shell.VolleyId);

        // reliable: a lost fire message means a shell that exists for the shooter but nobody else
        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    // maybe make contexts serializable?
    public static void SyncDamage(int hurtId, Color colorOverride) {
        if (!IsConnected() || MainMenuUI.IsActive)
            return;
        NetDataWriter message = new();
        message.Put(PacketID.TankDamage);

        message.Put(hurtId);

        message.Put(colorOverride);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SyncShellDestroy(Shell shell, Shell.DestructionContext cxt) {
        if (!IsConnected() || MainMenuUI.IsActive)
            return;
        NetDataWriter message = new();
        message.Put(PacketID.ShellDestroy);
        message.Put(shell.NetId);
        message.Put((byte)cxt);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    // maybe have owner stuff go here?
    public static void SyncMineDetonate(Mine mine) {
        if (!IsConnected() || MainMenuUI.IsActive)
            return;
        NetDataWriter message = new();
        message.Put(PacketID.MineDetonate);

        message.Put(mine.NetId);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SyncMinePlace(Mine mine) {
        if (MainMenuUI.IsActive || !IsConnected())
            return;

        NetDataWriter message = new();
        message.Put(PacketID.MinePlacement);

        message.Put(mine.Position);
        message.Put(mine.DetonateTime);
        message.Put(mine.Owner?.WorldId ?? -1);
        message.Put(mine.NetId);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendMessage(string text, Color color, string sender) {
        if (!IsConnected())
            return;
        NetDataWriter message = new();
        message.Put(PacketID.ChatMessage);

        message.Put(text);
        message.Put(color);
        message.Put(sender);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendServerNameChange(string newName) {
        if (!IsConnected())
            return;
        NetDataWriter message = new();
        message.Put(PacketID.ServerNameSync);
        message.Put(newName);

        Server.NetManager.SendToAll(message, DeliveryMethod.ReliableOrdered);
    }
    /// <summary>
    /// Sends a campaign through the connected server.
    /// 
    /// <para></para>
    /// 
    /// Sends in this order: <para></para>
    ///     Sends Campaign properties (name, lives, bg color, strip color), Mission Count
    ///     Then sends each: Block Count, Owner Count, Mission Name, Mission Note <para></para>
    ///         Then sends each: Mission Block (Position, Type, Stack, TpLink) <para></para>
    ///             Finally, sends each: Mission TankTemplate (Position, Rotation, IsPlayer, Team)
    ///             if IsPlayer is true, send PlayerType, otherwise send AIType
    /// 
    /// </summary>
    /// <param name="campaign">The campaign to send.</param>
    public static void SendCampaignBytes(Campaign campaign) {
        if (!IsConnected())
            return;
        NetDataWriter message = new();
        message.Put(PacketID.SendCampaign);

        message.Put(campaign.MetaData.Name);
        message.Put(campaign.MetaData.StartingLives);
        message.Put(campaign.MetaData.BackgroundColor);
        message.Put(campaign.MetaData.MissionStripColor);

        message.Put(campaign.CachedMissions.Length);

        foreach (var mission in campaign.CachedMissions) {
            message.Put(mission.Blocks.Length);
            message.Put(mission.Tanks.Length);

            message.Put(mission.Name);
            message.Put(mission.Note);

            foreach (var block in mission.Blocks) {
                message.Put(block.Position);
                message.Put(block.Type);
                message.Put(block.Stack);
                message.Put(block.TpLink);
            }
            foreach (var tank in mission.Tanks) {
                message.Put(tank.Position);
                message.Put(tank.Rotation);
                message.Put(tank.IsPlayer);
                message.Put(tank.Team);

                if (tank.IsPlayer)
                    message.Put(tank.PlayerType);
                else
                    message.Put(tank.AIType);
            }
        }

        NetClient.Send(message, DeliveryMethod.Sequenced);
    }
    public static void SendCampaignByName(string name, int missionId) {
        if (!IsConnected())
            return;
        NetDataWriter message = new();
        message.Put(PacketID.SendCampaign);

        message.Put(name);
        message.Put(missionId);

        // every client plays this game with the same seed
        var seed = Server.NewSessionSeed();
        Server.SetSessionSeed(seed);
        message.Put(seed);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendCampaignStatus(string campaignName, int clientId, bool success) {
        if (!IsConnected())
            return;
        NetDataWriter message = new();
        message.Put(PacketID.SendCampaignStatus);

        message.Put(campaignName);
        message.Put(clientId);
        message.Put(success);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendFile(string filePath) {
        var fBytes = File.ReadAllBytes(filePath);

        const int MAX_SEND_LEN = 1024; // i think?

        int numPacketsToSend = sizeof(byte) * fBytes.Length / MAX_SEND_LEN;

        // NetDataWriter message = new();

        // message.Put(numPacketsToSend);

        for (int i = 0; i < numPacketsToSend; i++) {
            var byteSplit = fBytes[(numPacketsToSend * i)..(numPacketsToSend * (i + 1))];

            // message.Put(byteSplit);
            SendCampaignBytes(byteSplit);
        }
    }
    public static void SendCampaignBytes(byte[] bytes) {
        NetDataWriter message = new();

        //message.Put(PacketID.SendCampaignBytes);
        message.Put(bytes);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendDiffiulties() {
        NetDataWriter message = new();

        message.Put(PacketID.SyncDifficulties);
        // by key, only what isn't at its default: clients reset everything else, and skip keys they don't have (mods)
        var values = Modifiers.NonDefaultValues();
        message.Put(values.Count);
        foreach (var (key, value) in values) {
            message.Put(key);
            message.Put(value);
        }
        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    public static void SendMapPing(Vector3 location, int pingId, int playerId) {
        NetDataWriter message = new();

        message.Put(PacketID.MapPing);
        message.Put(location);
        message.Put(pingId);
        message.Put(playerId);

        NetClient.Send(message, DeliveryMethod.ReliableOrdered);
    }
    /// <summary>Leaves the server and resets everything multiplayer, so a new game can be hosted or joined. If this client is the host, the server is
    /// stopped and every other client is disconnected. Safe to call more than once.</summary>
    public static void Disconnect() {
        NetPlay.UnmapClientNetworking();

        // tells all other clients that the host disconnected.
        NetPlay.TryUnmapServerNetworking();

        NetClient?.Disconnect();
        ClientManager?.Stop();
        NetClient = null;

        // leaving mid game goes back to the main menu
        if (!MainMenuUI.IsActive)
            GameUI.QuitOut(true);

        // the main menu puts this client's tank back when it isn't connected
        for (int i = 0; i < GameHandler.AllPlayerTanks.Length; i++)
            GameHandler.AllPlayerTanks[i]?.Remove(true);

        NetPlay.CurrentClient = null;
        NetPlay.CurrentServer = null;
        NetPlay.PeerMap.Clear();
        NetPlay.ReversePeerMap.Clear();
        NetPlay.LobbyClientCount = 0;
        LobbyDataReceived = false;

        Server.ConnectedClients = null;
        Server.NetManager = null;

        Server.CurrentClientCount = 0;

        MainMenuUI.ShouldServerButtonsBeVisible = true;
    }
    public static bool IsConnected() {
        if (NetClient is not null)
            return NetClient.ConnectionState == ConnectionState.Connected;
        return false;
    }
    public static bool IsHost() => Server.NetManager is not null;
}
