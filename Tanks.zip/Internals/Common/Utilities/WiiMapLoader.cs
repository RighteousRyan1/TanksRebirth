﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TanksRebirth.GameContent;
using TanksRebirth.GameContent.ID;
using TanksRebirth.GameContent.RebirthUtils;
using TanksRebirth.GameContent.Systems.Coordinates;
using TanksRebirth.GameContent.Tanks;
using TanksRebirth.GameContent.Tanks.AI;
using TanksRebirth.GameContent.UI.LevelEditor;

namespace TanksRebirth.Internals.Common.Utilities;
// todo: implement
public readonly struct WiiMap {
    public readonly struct WiiMapTileData(Point pos, int type, int stack) {
        public readonly Point Position = pos;
        public readonly int Type = type;
        /// <summary>-1 for player tank, -2 for enemy tank.</summary>
        public readonly int Stack = stack;
    }

    public const int LargeMapBytepool = 1512;

    public const int PLAYER_TANK_ID = -1;
    public const int ENEMY_TANK_ID = -2;

    public readonly byte[] RawData;

    public readonly int Width;
    public readonly int Height;

    public readonly int P1BalloonDirection;
    public readonly int P2BalloonDirection;
    public readonly List<WiiMapTileData> MapItems; // Point (xy pos), Kvp<int, int> (type, stack)
    public WiiMap(string file) {
        RawData = File.ReadAllBytes(file);
        if (RawData.Length < 0x10)
            throw new Exception("The file is too short to be a valid Wii Tanks map file.");

        Width = RawData.GetInt(0x0);
        Height = RawData.GetInt(0x4);

        if (RawData.Length != 0x10 + ((Height * Width) << 2))
            throw new Exception("The file header is invalid.");

        P2BalloonDirection = RawData[0xB];
        P1BalloonDirection = RawData[0xF];

        MapItems = [];
        for (var i = 0; i < Width * Height; i++) {
            var blockTypeOrig = RawData[i * 0x4 + 0x13];

            var tileMetaData = ConvertToEditorSpace(blockTypeOrig);
            // 731 == player tank byte position for the vanilla map
            var x = i % Width;
            MapItems.Add(new WiiMapTileData(new Point(x, i / Width), tileMetaData.Key, tileMetaData.Value));
        }
    }
    public static void SaveToTanksBinFile(string fileLocation, bool largeMap = true) {

        // Validate map before allocating memory and wasting resources in saving something we just can not save correctly.
        var validation = ValidateWiiMap();
        if (validation == WiiMapValidationResult.FailureTooManyPlayers) {
            LevelEditorUI.Alert("Too many players for Tanks! file format.", 240f);
            LevelEditorUI.EditState = LevelEditorUI.LevelEditState.LevelEditor;
            return;
        }
        else if (validation == WiiMapValidationResult.FailureTooManyAI) {
            LevelEditorUI.Alert("Too many AI for Tanks! file format.", 240f);
            LevelEditorUI.EditState = LevelEditorUI.LevelEditState.LevelEditor;
            return;
        }
        else if (validation == (WiiMapValidationResult.FailureTooManyPlayers | WiiMapValidationResult.FailureTooManyAI)) {
            LevelEditorUI.Alert("Too many AI AND players for Tanks! file format.", 240f);
            LevelEditorUI.EditState = LevelEditorUI.LevelEditState.LevelEditor;
            return;
        }

        var rawData = new byte[LargeMapBytepool];
        var byteOffset = 0x3; // 3 bytes

        void SetBit(byte[] dataCollection, int data) {
            dataCollection[byteOffset] = (byte)data;
            byteOffset += 0x4; // 4 bytes per tile
        }

        SetBit(rawData, (byte)(largeMap ? MapGrid.STD_WIDTH : MapGrid.WIDTH_43));

        SetBit(rawData, MapGrid.STD_HEIGHT);

        SetBit(rawData, 0);
        SetBit(rawData, 0);

        foreach (var pl in EditorTile.AllTiles) {
            if (pl.BlockId > -1 && pl.HasBlock) {
                var block = Block.AllBlocks[pl.BlockId];
                switch (block.Type) {
                    case BlockID.Wood:
                        SetBit(rawData, block.Stack + 200);
                        break;
                    case BlockID.Cork:
                        SetBit(rawData, block.Stack + 100);
                        break;
                    case BlockID.Hole:
                        SetBit(rawData, 200);
                        break;
                }
            }
            if (pl.TankId > -1) {
                var tank = GameHandler.AllTanks[pl.TankId];

                switch (tank) {
                    case PlayerTank player: {
                            if (player.PlayerType < 2) {
                                rawData[byteOffset - 0x1] = 1;
                                SetBit(rawData, player.PlayerType + 44);
                            }
                            break;
                        }
                    case AITank ai:
                        rawData[byteOffset - 0x1] = 1;
                        SetBit(rawData, ai.AITankId + 144);
                        break;
                }
            }
            if (pl is { BlockId: -1, TankId: -1 }) {
                SetBit(rawData, 0);
            }
        }

        File.WriteAllBytes(fileLocation, rawData);
    }

    private static WiiMapValidationResult ValidateWiiMap() {
        WiiMapValidationResult result = 0;
        var tankAiCount = 0;
        var playerCount = 0;
        for (var i = 0; i < EditorTile.AllTiles.Count; i++) {
            var pl = EditorTile.AllTiles[i];
            if (pl.TankId > -1) {
                var tnk = GameHandler.AllTanks[pl.TankId];
                if (tnk is PlayerTank)
                    playerCount++;
                else if (tnk is AITank)
                    tankAiCount++;
            }
        }
        if (tankAiCount > 8) result |= WiiMapValidationResult.FailureTooManyAI;
        if (playerCount > 2) result |= WiiMapValidationResult.FailureTooManyPlayers;

        return result;
    }

    public static void ApplyToGameWorld(WiiMap map) {
        EditorTile.ResetSquares();
        SceneManager.CleanupEntities();

        foreach (var mapTile in map.MapItems) {
            ProcessWiiMapTile(mapTile);
        }
    }

    private static void ProcessWiiMapTile(WiiMapTileData mapTile) {
        // the coordinates for the placements are just column and row, so look the square up on the grid
        var tile = EditorTile.At(mapTile.Position.X, mapTile.Position.Y);
        if (tile is null) return;

        /* Code used to debug Map processing, somewhat:
         *  if (tile.RelativePosition == new Point(5, 1))
         *  {
         *      ChatSystem.SendMessage($"Type: {item.Type}", Color.White);
         *      ChatSystem.SendMessage($"Stack: {item.Stack}", Color.White);
         *  }
         */

        if (mapTile.Type <= -1) return;

        if (mapTile.Stack is not (-1 or -2)) { // Normal tile, not a player.
            var bl = new Block(mapTile.Type, mapTile.Stack, tile.Position.FlattenZ());
            tile.BlockId = bl.Id;
            tile.HasBlock = true;
            return;
        }

        // This tile is basically a tank.

        var tnkRot = GetAutoTankRotation(tile.Cell.Coordinates.ToVector2()).ToRotation();

        switch (mapTile.Stack) {
            case PLAYER_TANK_ID: { // Player Owner, That's us!
                    var pl = DebugManager.SpawnMe(mapTile.Type, TeamID.Red, tile.Position);
                    pl.ChassisRotation = tnkRot;
                    pl.DesiredChassisRotation = tnkRot;
                    pl.TurretRotation = tnkRot;
                    tile.TankId = pl.WorldId;
                    break;
                }
            case ENEMY_TANK_ID: { // Enemy Owner.
                    var ai = DebugManager.SpawnTankAt(tile.Position, TankID.ClientRandomTier(), TeamID.Blue);
                    ai.ChassisRotation = tnkRot;
                    ai.DesiredChassisRotation = tnkRot;
                    ai.TurretRotation = tnkRot;
                    tile.TankId = ai.WorldId;
                    ai.ReassignId(mapTile.Type);
                    break;
                }
        }

        tile.HasBlock = false;
        return;
    }

    public static KeyValuePair<int, int> ConvertToEditorSpace(int input) {
        return input switch {
            0 => new(-1, 0), // this is an empty space.
            >= 101 and <= 107 => new(BlockID.Cork, input - 100),  // this would be a cork block in the binary file. (base 10 101-107)
            200 => new(BlockID.Hole, 0),                          // this is a hole in the binary file.
            >= 201 and <= 207 => new(BlockID.Wood, input - 200),  // this would be a wood block in the binary file. (base 10 201-207)
            >= 44 and <= 45 => new(input - 44, PLAYER_TANK_ID),   // respective blue and red player tank. -1 stack because we want to identify it.
            >= 144 and <= 151 => new(input - 144, ENEMY_TANK_ID), // -2 stack to identify as well, and since we can't identify the tank type, too bad.
            _ => throw new Exception($"Invalid conversion process to a {nameof(WiiMap)}.")
        };

        // unfortunately we cannot do much more than this, since enemy spawns are handled in the parameter file.
        // ...but we can find where they would spawn. go ahead and put a random tank on the red team there.

        // update: might try reading the parameters file to place appropriate tanks. this would also entail supporting ranged random tanks like the original game does, and also the ranged random maps
    }

    // why is this cancer? what did the original game do bruh
    // i will come back to this later.
    public static Facing GetAutoTankRotation(Vector2 p) {
        const float ROWS_PER_COL = (float)MapGrid.STD_HEIGHT / MapGrid.STD_WIDTH;

        // adjust to the center of the map.

        bool top_left = ROWS_PER_COL * p.X < p.Y;
        bool top_right = -ROWS_PER_COL * p.X < p.Y;

        if (top_left && top_right)
            return Facing.Up;
        if (top_left)
            return Facing.Right;
        if (top_right)
            return Facing.Left;
        return Facing.Down;
    }
}

[Flags]
public enum WiiMapValidationResult {
    Success = 0,
    FailureTooManyAI = 1 << 0,
    FailureTooManyPlayers = 1 << 1
}